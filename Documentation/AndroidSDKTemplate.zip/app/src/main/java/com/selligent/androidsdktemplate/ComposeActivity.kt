package com.selligent.androidsdktemplate

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import com.selligent.androidsdktemplate.ui.theme.AndroidSDKTemplateTheme
import com.selligent.sdk.SMDialog

class ComposeActivity : ComponentActivity()
{
    override fun onCreate(savedInstanceState: Bundle?)
    {
        super.onCreate(savedInstanceState)
        setContent {
            AndroidSDKTemplateTheme {
                // A surface container using the 'background' color from the theme
                Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    Greeting("Android")
                }

                //Add this call so that, if the app receives a push with an "alert" type in-app message, the dialog will show correctly
                //Note: if your app uses Jetpack Compose but your activities extend FragmentActivity or AppCompatActivity, the "old" dialog will work
                //and this call not have any effect.
                SMDialog()
            }
        }
    }
}

@Composable
fun Greeting(name: String, modifier: Modifier = Modifier)
{
    Text(
        text = "Hello $name!",
        modifier = modifier
    )
}

@Preview(showBackground = true)
@Composable
fun GreetingPreview()
{
    AndroidSDKTemplateTheme {
        Greeting("Android")
    }
}