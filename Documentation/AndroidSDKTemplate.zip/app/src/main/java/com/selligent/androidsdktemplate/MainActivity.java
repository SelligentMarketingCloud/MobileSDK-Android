package com.selligent.androidsdktemplate;

import androidx.fragment.app.FragmentTransaction;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;

import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentManager;
import androidx.lifecycle.Observer;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

//import com.selligent.sdk.SMBaseActivity;
import com.selligent.sdk.SMCallback;
import com.selligent.sdk.SMContentType;
import com.selligent.sdk.SMEvent;
import com.selligent.sdk.SMForegroundGcmBroadcastReceiver;
import com.selligent.sdk.SMInAppContent;
import com.selligent.sdk.SMInAppContentHtmlFragment;
import com.selligent.sdk.SMInAppContentImageFragment;
import com.selligent.sdk.SMInAppMessage;
import com.selligent.sdk.SMManager;
import com.selligent.sdk.SMNotificationButton;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Locale;
import java.util.Map;

//Each activity can extend SMBaseActivity in order to be able to display the push when they are received.
//In that case, nothing else needs to be done inside teh activity.
//If they do not, then some methods will have to be called on certain events.
//public class MainActivity extends SMBaseActivity

public class MainActivity extends FragmentActivity
{
    Context context = this;
    SMForegroundGcmBroadcastReceiver gcmReceiver;
    EventReceiver receiver;


    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button sendEventBtn = findViewById(R.id.eventBtn);
        sendEventBtn.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                //Here is an example of sending a custom event to the Selligent Mobile Platform.
                //The method is the same for all other events, only the object passed is different.

                //You can pass some data. It can be null.
                Hashtable<String, String> data = new Hashtable<>();
                data.put("key1", "value 1");
                data.put("key2", "value 2");
                data.put("key3", "value 3");

                //You can specify a callback to execute some operations once the event is sent. It can be null.
                SMCallback callback = new SMCallback()
                {
                    @Override
                    public void onSuccess(String s)
                    {
                        Toast toast = Toast.makeText(context, "Event sent", Toast.LENGTH_SHORT);
                        toast.show();
                    }

                    @Override
                    public void onError(int i, Exception e)
                    {
                        Toast toast = Toast.makeText(context, "Error", Toast.LENGTH_SHORT);
                        toast.show();
                    }
                };
                SMEvent event = new SMEvent(data, callback);
                SMManager.getInstance().sendSMEvent(event);
            }
        });


        //Here is an example of how to implement one of our In App content fragments
        //Let's say we want to display html content inside the page and an image full screen
        //The category having html content is "SomeHTMLCategory" and the one with images is "SomeImageCategory".
        //Categories are defined at In App content creation.
        //First, the HTML content, we want to display 3 contents:
        FragmentManager fragmentManager = getSupportFragmentManager();
        SMInAppContentHtmlFragment inAppContentHtmlFragment = SMInAppContentHtmlFragment.newInstance("SomeHTMLCategory", 3);

        //You can check if there is content.
        if (inAppContentHtmlFragment.hasContent())
        {
            FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();

            fragmentTransaction.replace(R.id.inAppContentPlaceHolder, inAppContentHtmlFragment, "HTML");
            fragmentTransaction.commit();
        }
        else
        {
            //There is no content, so you can display something else instead of the fragment if you want.
            //You can also listen to the broadcast sent after receiving In App Contents (cf. class EventReceiver) and,
            // if there is content for this category, then display the fragment.

            //Do stuff...
        }

        //Now, the image content (only one content is displayed for the image and URL contents):
        SMInAppContentImageFragment inAppContentImageFragment = SMInAppContentImageFragment.newInstance("SomeImageCategory");

        //No need to check in this case, if there isn't any image content for this category, nothing will be displayed.
        inAppContentImageFragment.show(fragmentManager, "Image");

        //On the other hand, if you want to manage the In App contents yourself without using our fragments, you can get them like this:
        ArrayList<SMInAppContent> contents = SMManager.getInstance().getInAppContents("SomeHTMLCategory", SMContentType.Html, 3);
        //Do stuff...

        //If you use SMRemoteMessageDisplayType.Notification in the settings and have several activities, you may want to overwrite change NOTIFICATION_ACTIVITY here
        SMManager.NOTIFICATION_ACTIVITY = this.getClass();


        //Here is how you can use observers to listen to our events and replace the broadcasts
        final Observer<String> tokenObserver = new Observer<String>()
        {
            @Override
            public void onChanged(String token)
            {
                Toast.makeText(MainActivity.this, "The GCM token received is: " + token + " (liveData)", Toast.LENGTH_SHORT).show();
            }
        };
        SMManager.getInstance().getObserverManager().observeToken(this, tokenObserver);

        final Observer<SMInAppMessage[]> inAppMessageObserver = new Observer<SMInAppMessage[]>()
        {
            @Override
            public void onChanged(SMInAppMessage[] inAppMessages)
            {
                if (inAppMessages != null)
                {
                    Toast.makeText(MainActivity.this, "Received " + inAppMessages.length + " InApp messages  (liveData)", Toast.LENGTH_SHORT).show();
                }
            }
        };
        SMManager.getInstance().getObserverManager().observeInAppMessages(this, inAppMessageObserver);

        final Observer<HashMap<String, Integer>> inAppContentObserver = new Observer<HashMap<String, Integer>>()
        {
            @Override
            public void onChanged(HashMap<String, Integer> categories)
            {
                if (categories != null)
                {
                    StringBuilder messageBuilder = new StringBuilder();
                    Iterator<Map.Entry<String, Integer>> categoryIterator = categories.entrySet().iterator();
                    while (categoryIterator.hasNext())
                    {
                        Map.Entry<String, Integer> entry = categoryIterator.next();
                        String category = entry.getKey();
                        int count = entry.getValue();

                        messageBuilder.append(String.format(Locale.getDefault(), "%s : %d\n", category, count));
                    }
                    Toast.makeText(MainActivity.this, "Received contents:" + messageBuilder.toString() + " (liveData)", Toast.LENGTH_SHORT).show();
                }
            }
        };
        SMManager.getInstance().getObserverManager().observeInAppContents(this, inAppContentObserver);

        final Observer<SMNotificationButton> clickedButtonObserver = new Observer<SMNotificationButton>()
        {
            @Override
            public void onChanged(SMNotificationButton button)
            {
                if (button != null)
                {
                    Toast.makeText(MainActivity.this, "The button \"" + button.label + "\" was clicked (liveData)", Toast.LENGTH_SHORT).show();
                }
            }
        };
        SMManager.getInstance().getObserverManager().observeClickedButton(this, clickedButtonObserver);

        final Observer<Void> dismissedMessageObserver = new Observer<Void>()
        {
            @Override
            public void onChanged(Void object)
            {
                Toast.makeText(MainActivity.this, "A notification is about to be dismissed (liveData)", Toast.LENGTH_SHORT).show();
            }
        };
        SMManager.getInstance().getObserverManager().observeDismissedMessage(this, dismissedMessageObserver);

        final Observer<Void> displayedMessageObserver = new Observer<Void>()
        {
            @Override
            public void onChanged(Void object)
            {
                Toast.makeText(MainActivity.this, "A notification is about to be displayed (liveData)", Toast.LENGTH_SHORT).show();
            }
        };
        SMManager.getInstance().getObserverManager().observeDisplayedMessage(this, displayedMessageObserver);

        final Observer<String> customEventObserver = new Observer<String>()
        {
            @Override
            public void onChanged(String event)
            {
                switch(event)
                {
                    case "CustomEvent":
                        Toast.makeText(MainActivity.this, "Custom event triggered", Toast.LENGTH_SHORT).show();
                        break;

                    case "testEventFromIAC":
                        Toast.makeText(MainActivity.this, "You clicked in an In App Content!", Toast.LENGTH_SHORT).show();
                        break;
                }
            }
        };
        SMManager.getInstance().getObserverManager().observeEvent(this, customEventObserver);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu)
    {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings)
        {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }


    @Override
    protected void onStart()
    {
        super.onStart();

        //If you have several activities and you want the current one to be called when clicking on a notification (especially if you set AutomaticDisplayOfRemoteMessages to false),
        //use this line in your base activity
        //SMManager.NOTIFICATION_ACTIVITY = getClass();

        //In order to listen to the different local broadcasts sent by the SDK, you have to register a receiver with the LocalBroadcastManager
        /* LocalBroadcastReceiver is now deprecated with the latest version of the AndroidX libraries, so we also deprecated all pour broadcasts.
         * Although they are still sent, we recommend to migrate to observers

        if (receiver == null)
        {
            receiver = new EventReceiver();
        }
        IntentFilter filter = new IntentFilter();
        //The value set here must be the same as the one given to the CustomActionBroadcastEvent button
        filter.addAction("CustomEvent");
        //The following are the different broadcasts sent by the SDK
        filter.addAction(SMManager.BROADCAST_EVENT_RECEIVED_IN_APP_MESSAGE);
        filter.addAction(SMManager.BROADCAST_EVENT_RECEIVED_IN_APP_CONTENTS);
        filter.addAction(SMManager.BROADCAST_EVENT_RECEIVED_REMOTE_NOTIFICATION);
        filter.addAction(SMManager.BROADCAST_EVENT_WILL_DISPLAY_NOTIFICATION);
        filter.addAction(SMManager.BROADCAST_EVENT_WILL_DISMISS_NOTIFICATION);
        filter.addAction(SMManager.BROADCAST_EVENT_BUTTON_CLICKED);
        filter.addAction(SMManager.BROADCAST_EVENT_RECEIVED_GCM_TOKEN);
        LocalBroadcastManager.getInstance(this).registerReceiver(receiver, filter);
        */


        //If you want to retrieve the stored GCM Token, you can call teh following method.
        //Please note that due to the GCM registration process being asynchronous, the value returned may be empty or not up-to-date.
        //To be sure to be alerted as soon as the token changes, be sure to listen to the corresponding broadcast.
        String gcmToken = SMManager.getInstance().getGCMToken();


        //The following methods must only be executed if the activity does not extend SMBaseActivity
        if (gcmReceiver == null)
        {
            gcmReceiver = new SMForegroundGcmBroadcastReceiver(this);
        }
        registerReceiver(gcmReceiver, gcmReceiver.getIntentFilter());

        //The following method must only be called if the activity does not extend SMBaseActivity
        SMManager.getInstance().checkAndDisplayMessage(getIntent(), this);

        //If you want to use geofencing, you have to enable it
        SMManager.getInstance().enableGeolocation();

        //When you want to disable geofencing (or allow the user to do it), you have to call
        SMManager.getInstance().disableGeolocation();

        //If you want to know if geofencing is enabled, simply call
        boolean enabled = SMManager.getInstance().isGeolocationEnabled();
    }

    @Override
    protected void onStop()
    {
        super.onStop();

        unregisterReceiver(gcmReceiver);
        LocalBroadcastManager.getInstance(this).unregisterReceiver(receiver);
    }

    @Override
    protected void onNewIntent(Intent intent)
    {
        super.onNewIntent(intent);

        //The following method must only be called if the activity does not extend SMBaseActivity
        SMManager.getInstance().checkAndDisplayMessage(intent, this);
    }

    @Override
    protected void onDestroy()
    {
        super.onDestroy();

        //If you use SMRemoteMessageDisplayType.Notification in the settings and have several activities, you may want to revert NOTIFICATION_ACTIVITY here to the default one set at start
        //NB: in this template, there is only one activity, so it is useless
        SMManager.NOTIFICATION_ACTIVITY = MainActivity.class;
    }
}
