package com.selligent.androidsdktemplate;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;

import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;
import com.selligent.sdk.OnSMNotificationMessageRetrieved;
import com.selligent.sdk.SMManager;
import com.selligent.sdk.SMNotificationButton;
import com.selligent.sdk.SMNotificationMessage;

import androidx.annotation.NonNull;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.core.app.TaskStackBuilder;

public class MessagingService extends FirebaseMessagingService
{
    final String CHANNEL_ID = "MyCustomNotifications";

    @Override
    public void onMessageReceived(@NonNull RemoteMessage message)
    {
            //If you want to manage the notifications yourself, you can implement this kind of service and retrieve the payload of the push this way:
            SMManager.getInstance().retrieveNotificationMessage(message.toIntent(), new OnSMNotificationMessageRetrieved()
            {
                @Override
                public void onSuccess(@NonNull SMNotificationMessage smNotificationMessage)
                {
                    //Send a pushReceived event to the Marigold Engage Mobile platform, call it when you receive the push.
                    SMManager.getInstance().setNotificationMessageAsReceived(smNotificationMessage);

                    //Do stuff with the payload...

                    //Here are the other helper methods, call them when needed
                    //SMManager.getInstance().setNotificationMessageAsSeen(smNotificationMessage);
                    //SMManager.getInstance().setButtonAsClicked(smNotificationMessage, smNotificationMessage.getNotificationButtons()[0]);
                }

                @Override
                public void onError(Exception e)
                {
                }
            });
    }
}
