package com.selligent.androidsdktemplate;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.widget.Toast;

import com.selligent.sdk.SMInAppMessage;
import com.selligent.sdk.SMManager;
import com.selligent.sdk.SMNotificationButton;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Locale;
import java.util.Map;

//LocalBroadcastReceiver is now deprecated with the latest version of the AndroidX libraries, so we also deprecated all pour broadcasts.
//Although they are still sent, we recommend to migrate to observers

//This receiver will listen to the events sent by a CustomActionBroadcastEvent type button in a push.
public class EventReceiver extends BroadcastReceiver
{
    public EventReceiver()
    {

    }

    @Override
    public void onReceive(Context context, Intent intent)
    {
        String action = intent.getAction();
        Toast toast = null;

        switch (action)
        {
            case SMManager.BROADCAST_EVENT_RECEIVED_IN_APP_MESSAGE:
                SMInAppMessage[] messages = (SMInAppMessage[])intent.getSerializableExtra(SMManager.BROADCAST_DATA_IN_APP_MESSAGES);
                toast = Toast.makeText(context, "Received " + messages.length + " InApp messages", Toast.LENGTH_SHORT);
                break;

            case SMManager.BROADCAST_EVENT_RECEIVED_IN_APP_CONTENTS:
                HashMap<String, Integer> categories = (HashMap<String, Integer>) intent.getSerializableExtra(SMManager.BROADCAST_DATA_IN_APP_CONTENTS);
                StringBuilder messageBuilder = new StringBuilder();

                for (Map.Entry<String, Integer> categoryEntry : categories.entrySet())
                {
                    String category = categoryEntry.getKey();
                    int count = categoryEntry.getValue();

                    messageBuilder.append(String.format("\n%s : %d", category, count));
                }
                toast = Toast.makeText(context, "Received contents:" + messageBuilder.toString(), Toast.LENGTH_SHORT);
                break;

            case SMManager.BROADCAST_EVENT_BUTTON_CLICKED:
                SMNotificationButton button = (SMNotificationButton)intent.getSerializableExtra(SMManager.BROADCAST_DATA_BUTTON);
                toast = Toast.makeText(context, "The button \"" + button.label + "\" was clicked", Toast.LENGTH_SHORT);
                break;

            case SMManager.BROADCAST_EVENT_WILL_DISPLAY_NOTIFICATION:
                toast = Toast.makeText(context, "A notification is about to be displayed", Toast.LENGTH_SHORT);
                break;

            case SMManager.BROADCAST_EVENT_WILL_DISMISS_NOTIFICATION:
                toast = Toast.makeText(context, "A notification is about to be dismissed", Toast.LENGTH_SHORT);
                break;

            case SMManager.BROADCAST_EVENT_RECEIVED_GCM_TOKEN:
                toast = Toast.makeText(context, "The GCM token received is: " + intent.getStringExtra(SMManager.BROADCAST_DATA_GCM_TOKEN), Toast.LENGTH_SHORT);
                break;
        }

        if (toast != null)
        {
            toast.show();
        }
    }
}
