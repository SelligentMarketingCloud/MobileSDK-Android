package com.selligent.androidsdktemplate;

import android.app.Application;

import com.selligent.sdk.SMClearCache;
import com.selligent.sdk.SMInAppRefreshType;
import com.selligent.sdk.SMManager;
import com.selligent.sdk.SMRemoteMessageDisplayType;
import com.selligent.sdk.SMSettings;

//You can extend the SMApplication class (which extends Application) to initialize the Marigold Engage Mobile SDK
//public class CustomApp extends SMApplication

//You can also start the SDK from an existing Application extension
public class CustomApp extends Application
{
    @Override
    public void onCreate()
    {
        //Initialize the Marigold Engage Mobile SDK like this

        //First create a SMSetting object
        SMSettings settings = new SMSettings();

        //The service URL given by Marigold Engage
        settings.WebServiceUrl = "https://your.own.url/Mobilepush/Api";

        //The client ID given by Marigold Engage
        settings.ClientId = "Some-Client-id";

        //The private key given by Marigold Engage
        settings.PrivateKey = "SomePrivateKey";

        //If you want to allow in app messages management, set this value
        settings.InAppMessageRefreshType = SMInAppRefreshType.Hourly;

        //If you want to allow in app contents management, set this value
        settings.InAppContentRefreshType = SMInAppRefreshType.Hourly;

        //If you want to specify a specific lifespan for the items in the cache.
        settings.ClearCacheIntervalValue = SMClearCache.Month;

        //If you want to disable the automatic display of remote messages
        settings.RemoteMessageDisplayType = SMRemoteMessageDisplayType.Notification;

        //If you want to use an existing notification channel
        settings.NotificationChannelId = "MyOwnChannelId";

        //If you want to give a specific name to the notification channel (if the channel already exists, its name will be updated)
        settings.NotificationChannelName = "Promotions";

        //If you want to give a specific description to the notification channel (if the channel already exists, its description will be updated)
        settings.NotificationChannelDescription = "For the promotion notifications";

        //Set it to true to be able to see the logs created by the Marigold Engage Mobile SDK
        SMManager.DEBUG = true;

        //Do this to specify which activity will be called when clicking on a notification created after receiving a push when the app is in background
        SMManager.NOTIFICATION_ACTIVITY = MainActivity.class;

        //Do this to specify which activity is teh main one of the app. This allows the SDK to show potentially show a dialog only on that activity (mainly for old OS versions when the user needs to update Google services or some security protocol)
        SMManager.MAIN_ACTIVITY = MainActivity.class;

        //This will actually start the SDK. Use this version of start ONLY if you do not extend SMApplication
        SMManager.getInstance().start(settings, this);

        //If you extend SMApplication, you have to use the following version:
        //SMManager.getInstance().start(settings);


        //You can specify your own icon for the notifications this way
        //SMManager.getInstance().setNotificationSmallIcon(R.drawable.your_notif_icon);



        //!!!!!The following methods are placed here as examples, they should not be called right after a start or, as a matter of fact, in an Application class!!!!!

        //If you want to disable the notifications, call this method
        //SMManager.getInstance().disableNotifications();

        //If you want to re-enable the notifications after disabling them, call this method.
        //Typically, this will be used if you want to give the user the ability to enable/disable the notifications
        //Notifications are enabled by default so you should not call this method unless a disabled was previously done.
        //SMManager.getInstance().enableNotifications();

        //If you want to disable the in app messages, call this method
        //SMManager.getInstance().disableInAppMessages();

        //If you want to re-enable the in-app messages after disabling them, or change the refresh type, call this method
        //Typically, this will be used if you want to give the user the ability to enable/disable the in-app messages or change the way they are retrieved
        //In-app messages are enabled by setting a value to InAppMessageRefreshType on the SMSettings object.
        //SMManager.getInstance().enableInAppMessages(SMInAppRefreshType.Daily);

        //If you want to know if the automatic display of remote messages is enabled
        //SMRemoteMessageDisplayType displayType = SMManager.getInstance().getRemoteMessagesDisplayType();

        super.onCreate();
    }
}
